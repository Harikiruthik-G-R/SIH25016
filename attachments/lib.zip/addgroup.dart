import 'package:flutter/material.dart';
import 'navbar.dart';
import 'groups.dart'; // Make sure to import groups.dart

class AddGroupFormScreen extends StatefulWidget {
  const AddGroupFormScreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _AddGroupFormScreenState createState() => _AddGroupFormScreenState();
}

class _AddGroupFormScreenState extends State<AddGroupFormScreen> {
  bool? _isSameOrganization;
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _groupNameController = TextEditingController();
  final TextEditingController _totalMembersController = TextEditingController();
  final TextEditingController _organizationNameController =
      TextEditingController();
  final TextEditingController _purposeController = TextEditingController();
  final TextEditingController _adminsController = TextEditingController();

  Color? _selectedColor;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Group'),
      ),
      drawer: const AppNavigationDrawer(),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _groupNameController,
                  decoration: const InputDecoration(
                    labelText: 'Group name',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Group name is required';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _totalMembersController,
                  decoration: const InputDecoration(
                    labelText: 'Total Members',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Total Members is required';
                    }
                    if (int.tryParse(value) == null) {
                      return 'Enter a valid number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                const Text('Under Same Organization:'),
                Row(
                  children: [
                    Radio<bool?>(
                      value: true,
                      groupValue: _isSameOrganization,
                      onChanged: (bool? value) {
                        setState(() {
                          _isSameOrganization = value;
                        });
                      },
                    ),
                    const Text('Yes'),
                    Radio<bool?>(
                      value: false,
                      groupValue: _isSameOrganization,
                      onChanged: (bool? value) {
                        setState(() {
                          _isSameOrganization = value;
                        });
                      },
                    ),
                    const Text('No'),
                  ],
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _organizationNameController,
                  decoration: const InputDecoration(
                    labelText: 'Organization Name',
                  ),
                  enabled: _isSameOrganization == false,
                  validator: (value) {
                    if (_isSameOrganization == false &&
                        (value == null || value.isEmpty)) {
                      return 'Organization Name is required';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _purposeController,
                  decoration: const InputDecoration(
                    labelText: 'Purpose',
                  ),
                  enabled: _isSameOrganization == false,
                  maxLines: 3,
                  validator: (value) {
                    if (_isSameOrganization == false &&
                        (value == null || value.isEmpty)) {
                      return 'Purpose is required';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _adminsController,
                  decoration: const InputDecoration(
                    labelText: 'Add other Admins',
                    hintText: 'admin1@gmail.com, admin2@gmail.com',
                  ),
                  // validator: (value) {
                  //   if (value == null || value.isEmpty) {
                  //     return 'Please provide at least one admin';
                  //   }
                  //   return null;
                  // },
                ),
                const SizedBox(height: 16),
                const Text('Select color:'),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedColor = Colors.red;
                        });
                      },
                      child: Container(
                        color: Colors.red,
                        height: 30,
                        width: 30,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedColor = Colors.pink;
                        });
                      },
                      child: Container(
                        color: Colors.pink,
                        height: 30,
                        width: 30,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedColor = Colors.blue;
                        });
                      },
                      child: Container(
                        color: Colors.blue,
                        height: 30,
                        width: 30,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedColor = Colors.green;
                        });
                      },
                      child: Container(
                        color: Colors.green,
                        height: 30,
                        width: 30,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Center(
                  child: ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => GroupsScreen(
                              groupName: _groupNameController.text,
                              totalMembers: _totalMembersController.text,
                              color: _selectedColor!,
                            ),
                          ),
                        );
                      }
                    },
                    child: const Text('Create'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _groupNameController.dispose();
    _totalMembersController.dispose();
    _organizationNameController.dispose();
    _purposeController.dispose();
    _adminsController.dispose();
    super.dispose();
  }
}
