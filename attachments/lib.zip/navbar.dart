// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'addgroup.dart';
import 'groups.dart';

class AppNavigationDrawer extends StatefulWidget {
  const AppNavigationDrawer({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _AppNavigationDrawerState createState() => _AppNavigationDrawerState();
}

class _AppNavigationDrawerState extends State<AppNavigationDrawer> {
  String _activeItem = 'Dashboard'; // Keep track of active item

  @override
  Widget build(BuildContext context) {
    return Drawer(
      width: MediaQuery.of(context).size.width * 0.6,
      child: Column(
        children: <Widget>[
          DrawerHeader(
            child: Image.asset(
              'assets/images/Splash.png',
            ),
          ),
          ListTile(
            leading: Icon(
              Icons.dashboard,
              color: _activeItem == 'Dashboard' ? Colors.green : null,
            ),
            title: Text(
              'Dashboard',
              style: TextStyle(
                  color: _activeItem == 'Dashboard' ? Colors.green : null),
            ),
            onTap: () {
              setState(() {
                _activeItem = 'Dashboard';
              });
              Navigator.of(context).pop(); // Close the drawer
              // Navigate to HomeScreen if not already there
              if (ModalRoute.of(context)?.settings.name != '/home') {
                Navigator.of(context).pushReplacementNamed('/home');
              }
            },
          ),
          ListTile(
            leading: Icon(
              Icons.group_add,
              color: _activeItem == 'Add Groups' ? Colors.green : null,
            ),
            title: Text(
              'Add Groups',
              style: TextStyle(
                  color: _activeItem == 'Add Groups' ? Colors.green : null),
            ),
            onTap: () {
              setState(() {
                _activeItem = 'Add Groups';
              });
              Navigator.of(context).pop();
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => const AddGroupFormScreen()));
            },
          ),
          ListTile(
            leading: Icon(
              Icons.person,
              color: _activeItem == 'Active users' ? Colors.green : null,
            ),
            title: Text(
              'Active users',
              style: TextStyle(
                  color: _activeItem == 'Active users' ? Colors.green : null),
            ),
            onTap: () {
              setState(() {
                _activeItem = 'Active users';
              });
              Navigator.of(context).pop();
            },
          ),
          ListTile(
            leading: Icon(
              Icons.location_on,
              color: _activeItem == 'Set Coordinates' ? Colors.green : null,
            ),
            title: Text(
              'Set Coordinates',
              style: TextStyle(
                  color:
                      _activeItem == 'Set Coordinates' ? Colors.green : null),
            ),
            onTap: () {
              setState(() {
                _activeItem = 'Set Coordinates';
              });
              Navigator.of(context).pop();
            },
          ),
          ListTile(
            leading: Icon(
              Icons.bar_chart,
              color: _activeItem == 'Statistics' ? Colors.green : null,
            ),
            title: Text(
              'Statistics',
              style: TextStyle(
                  color: _activeItem == 'Statistics' ? Colors.green : null),
            ),
            onTap: () {
              setState(() {
                _activeItem = 'Statistics';
              });
              Navigator.of(context).pop();
            },
          ),
          ListTile(
            leading: Icon(
              Icons.search,
              color: _activeItem == 'Search' ? Colors.green : null,
            ),
            title: Text(
              'Search',
              style: TextStyle(
                color: _activeItem == 'Search' ? Colors.green : null,
              ),
            ),
            onTap: () {
              setState(() {
                _activeItem = 'Search';
              });
              Navigator.of(context).pop();
            },
          ),
          ListTile(
            leading: Icon(
              Icons.group,
              color: _activeItem == 'Groups' ? Colors.green : null,
            ),
            title: Text(
              'Groups',
              style: TextStyle(
                color: _activeItem == 'Groups' ? Colors.green : null,
              ),
            ),
            onTap: () {
              setState(() {
                _activeItem = 'Groups';
              });
              Navigator.of(context).pop();
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => GroupsScreen(
                    groupName: 'Default Group',
                    totalMembers: '0',
                    color: Colors.grey,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
