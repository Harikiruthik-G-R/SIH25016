// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'navbar.dart'; // Ensure this is your AppNavigationDrawer

class GroupsScreen extends StatelessWidget {
  final String groupName;
  final String totalMembers;
  final Color color;

  const GroupsScreen({
    super.key,
    required this.groupName,
    required this.totalMembers,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Groups'),
      ),
      drawer: const AppNavigationDrawer(), // Add the drawer here
      body: Center(
        child: Container(
          color: color,
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                groupName,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'Total Members: $totalMembers',
                style: TextStyle(fontSize: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
